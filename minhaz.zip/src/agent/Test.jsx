import React, { useEffect, useState } from 'react'
import { fetchData } from '../features/agentApi'
import { testLogo, testTick } from '../assets';
import TestComponent from './testComponent';

const Test = () => {
const [isData, setIsData] = useState();



const testData = async()=>{
    try{
   const res = await fetchData()
   setIsData(res.data.dataPoints);
   console.log(res.data, "testData")
    }catch(error){
   console.log(error, "Error while fetcghing Data")
    }
}


useEffect(()=>{
testData()
}, [])
  return (
<>
<div className='bgtest   pb-16   '> 
<span className='ml-[29%] flex flex-row  pt-6'>
<span className='flex flex-row items-center gap-52'>
<span className='bg-white text-medium px-6 py-1 rounded-md' >Contact Us </span>
<select className='bg-white text-black px-9 py-2 rounded-md'>
<option value="">Select Language</option>
</select>
</span>

<span className='flex flex-row items-center ml-72 gap-3'>
  <img src={testTick} alt="" />
   <span className='text-white'>Verified</span>
</span>
</span>
<img src={testLogo} alt="img" className='mx-6 mt-6' />

</div>
<div className='-mt-9'>

<TestComponent isData={isData}/>
</div>
</>
  )
}

export default Test