import React from "react";
import { profileSkeleton } from "../assets";
import { FaUser } from "react-icons/fa";
import { GiTwoCoins } from "react-icons/gi";
import { HiOutlineClipboardDocumentList } from "react-icons/hi2";
import { filterType } from "../constant/data";
import LineChart, {
  LineChartAgent,
} from "../components/dashboardComp/charts/LineChart";
import { formatDate } from "./../constant/commonfunction";

const TestComponent = ({ isData }) => {
  const monthNames = isData?.map((data, index) => formatDate(data.label));
  const filteredLineData = {
    labels: monthNames,
    label: `Total Number`,
    datasets: isData?.map((data, index) => data.y),
  };

  return (
    <>
      <div className="flex flex-row items-start gap-6 w-full justify-start  ">
        <div className=" rounded-r-lg w-[20%] flex flex-col items-center bgtest shadow pb-24">
          <img
            src={profileSkeleton}
            alt="img"
            loading="lazy"
            className="rounded-full w-20 h-20 mt-6"
          />
          <span className="font-medium text-[17px]">Prateek Yadav</span>
          <span className="text-[14px]">Online</span>
          <span className=" bg-white px-6 rounded-md mt-6 flex flex-row items-center gap-4 ">
            <span className="text-yellow-500">
              <GiTwoCoins />
            </span>
            <span>12,53,588</span>
          </span>

          <span className=" bg-white px-9 py-2 rounded-md mt-9 flex flex-row items-center gap-4  ">
            <span className="text-black">
              <FaUser />
            </span>
            <span className="text-[14px]">Profile</span>
          </span>
          <span className=" bg-white px-6 rounded-md py-2 flex flex-row items-center gap-4 mt-6 ">
            <span className="text-blue-500">
              <HiOutlineClipboardDocumentList />
            </span>
            <span className="text-[14px]"> My Gold Plans</span>
          </span>
          <span className=" bg-white px-6 rounded-md mt-9 flex flex-row items-center gap-4 ">
            <span className="text-yellow-500">
              <GiTwoCoins />
            </span>
            <span> Tokens</span>
          </span>
        </div>

        <div className=" rounded-lg w-[60%] flex flex-col items-center bgtest shadow pb-5">
          <span className="flex flex-row items-center  justify-evenly text-white w-full mt-6">
            <select
              name=""
              id=""
              className="bg-transparent  rounded-md px-3 border border-white"
            >
              <option value="">Gold Price</option>
            </select>

            <span className="font-semibold text-[22px]">
              Gold Prices Overtime
            </span>
            <select
              name=""
              id=""
              className="bg-transparent  rounded-md px-3 border border-white"
            >
              <option value="">USD</option>
            </select>
          </span>

          <div className="flex flex-row items-center gap-6">
            {filterType?.map((data) => {
              <span
                key={data.id}
                className="border border-white rounded-full text-white "
              >
                {data.option}
              </span>;
            })}
          </div>
          <div className="px-9  py-4 rounded-md mt-12 md:w-[100%] h-auto">
            <LineChartAgent data={filteredLineData} />
          </div>
        </div>

        <div className=" rounded-l-lg w-[20%] flex flex-col items-start px-3 bgtest shadow ">
          <span className=" bg-yellow-200 px-6 rounded-md mt-6 flex flex-row justify-end items-center gap-4 ml-20">
            <span className="text-yellow-500">
              <GiTwoCoins />
            </span>
            <span className="text-[14px] font-medium">My Token</span>
          </span>
          <span className="font-medium text-[13px] mt-3 text-white">
            Live Gold Price
          </span>
          <span className="text-[14px] text-yellow-300">
            $ 83,560,202 /-per gram
          </span>
          <span className="font-medium text-[13px] mt-3 text-white">
            Usable Gold Qty
          </span>
          <span className="text-[14px] text-yellow-300">
            $ 83,560,202 /-per gram
          </span>{" "}
          <span className="flex flex-row items-center gap-2">
            <span>
              <span className="font-medium text-[13px] mt-3 text-white">
                Usable Gold Current
              </span>
              <p className="text-[14px] text-yellow-300">
                $ 83,560,202 /-per gram
              </p>
            </span>
            <span>
              <span className="font-medium text-[13px] mt-3 text-white">
                Profit/Loss
              </span>
              <p className="text-[14px] text-yellow-300">$ 83,560,202</p>
            </span>
          </span>
          <span className="flex flex-row items-center gap-6 w-full mt-6">
            <span className="bg-[#D9D9D9]  text-medium rounded-md text-[14px] px-3 py-2 cursor-pointer">
              Gold Plans
            </span>
            <span className="border border-[#D9D9D9] text-white  text-medium rounded-md text-[14px] px-3 py-2 cursor-pointer">
              Gold Balance
            </span>
          </span>
          <select
            name=""
            id=""
            className="bg-transparent  w-full rounded-md px-3 border border-white mt-6 py-2"
          >
            <option value="" className="">
              Select Gold Plans
            </option>
          </select>
          <div className="border border-white px-3 py-3 rounded-md mt-6">
            <span className="text-white">Gram</span>
            <input
              className="text-white bg-transparent border border-white w-full rounded-md mb-3 "
              type="text"
            />
            <span className="text-white ">Gram</span>

            <input
              className="text-white bg-transparent border border-white w-full rounded-md "
              type="text"
            />
          </div>
          <div className="mt-6 flex justify-center w-full">
            <span className="text-[14px] bg-yellow-200 px-6 py-2 rounded-md">
              Sell Gold
            </span>
          </div>
        </div>
      </div>
    </>
  );
};

export default TestComponent;
