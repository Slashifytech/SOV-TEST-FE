import { RouterProvider, useNavigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  getCountryOption,
  getCourses,
  getPrefCountryOption,
} from "./features/generalSlice";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { router } from "./routes/Route";
import { agentInformation } from "./features/agentSlice";
import { studentInfo } from "./features/studentSlice";
import {
  getAdminConnectionDetails,
  getConnectionDetails,
} from "./features/getConnectionDetails";
import socketServiceInstance from "./services/socket";
import { io } from "socket.io-client";
import { adminProfileData, getMemberProfile } from "./features/adminSlice";
import { startTokenHeartbeat } from "./services/tokenCheck";

function App() {



  return (
    <>
      <ToastContainer position="top-center" autoClose={5000} hideProgressBar />
      <div className="overflow-hidden">
        <RouterProvider router={router} />
      </div>
    </>
  );
}

export default App;
